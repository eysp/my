# install-program

Install to emmc script for phicomm n1 or beikeyun, it can help you to install the openwrt system to the emmc storage.  

Usage:  

* phicomm n1  
`n1-install`, install to emmc  
`n1-update` , upgrade form `/tmp/upgrade/xxx.img` ( upload by yourself )  

* beikeyun  
`beikeyun-update ${firmwarepath}`, upgrade form `${firmwarepath}` ( must be an absolute path )
